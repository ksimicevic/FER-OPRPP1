package hr.fer.oprpp1.hw08.jnotepad.local;

public interface ILocalizationListener {
    void localizationChanged();
}
